/**
 * Created by grachro on 2016/01/12.
 */
public int plus() {
    a + b
}

public int minus() {
    a - b
}
