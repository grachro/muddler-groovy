database name: "sqlite3",
        url: "jdbc:sqlite:workspace/sample.sqlite3",
        user: null,
        password: null,
        driverClassName: "org.sqlite.JDBC"


